package set;

public class DisjointSet {

    private int[] parent;
    private int[] rank;

    public DisjointSet(int size) {
        throw new UnsupportedOperationException();
    }

    public int[] getParent() {
        return parent;
    }

    public void setParent(int[] parent) {
        this.parent = parent;
    }

    public int[] getRank() {
        return rank;
    }

    public void setRank(int[] rank) {
        this.rank = rank;
    }

    public void makeSet(int index) {
        throw new UnsupportedOperationException();
    }

    public int find(int index) {
        throw new UnsupportedOperationException();
    }

    public int findWithPathCompression(int index) {
        throw new UnsupportedOperationException();
    }

    public void union(int i, int j) {
        throw new UnsupportedOperationException();
    }

}
