package heap;

public class MaxHeap {

    private int[] array;
    private int size;

    public MaxHeap() {
        this.array = new int[2];
        this.size = 0;
    }

    public int[] getArray() {
        return array;
    }

    public void setArray(int[] array) {
        this.array = array;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    private int parent(int index) {
        throw new UnsupportedOperationException();
    }

    private int leftChild(int index) {
        throw new UnsupportedOperationException();
    }

    private int rightChild(int index) {
        throw new UnsupportedOperationException();
    }

    public void buildHeap(int[] array) {
        throw new UnsupportedOperationException();
    }

    public void insert(int value) {
        throw new UnsupportedOperationException();
    }

    public int extractMax() {
        throw new UnsupportedOperationException();
    }

    public void sort(int[] array) {
        throw new UnsupportedOperationException();
    }

}
