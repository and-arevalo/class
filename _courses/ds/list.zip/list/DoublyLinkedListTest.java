package list;

import org.junit.Test;

import java.util.LinkedList;
import java.util.Random;

import static org.junit.Assert.assertEquals;

public class DoublyLinkedListTest {

    private final Random random = new Random();

    private void test(LinkedList<Integer> expected, DoublyLinkedList<Integer> actual) {
        assertEquals(expected.size(), actual.size());
        for (int i = 0; i < expected.size(); i++) {
            assertEquals(expected.get(i), actual.get(i));
        }
    }

    @Test
    public void pushAndPop() {
        LinkedList<Integer> expected = new LinkedList<>();
        DoublyLinkedList<Integer> actual = new DoublyLinkedList<>();

        assertEquals(true, actual.isEmpty());

        for (int i = 0; i < 100; i++) {
            Integer key = random.nextInt();
            expected.addFirst(key);
            actual.pushFront(key);
            assertEquals("pushFront", expected.getFirst(), actual.topFront());

            key = random.nextInt();
            expected.addLast(key);
            actual.pushBack(key);
            assertEquals("pushFront", expected.getLast(), actual.topBack());
        }
        test(expected, actual);
        assertEquals(false, actual.isEmpty());

        for (int i = 0; i < 100; i++) {
            assertEquals("popFront", expected.removeFirst(), actual.popFront());
            assertEquals("popBack", expected.removeLast(), actual.popBack());
        }
        test(expected, actual);
        assertEquals(true, actual.isEmpty());
    }

    @Test
    public void find() {
        DoublyLinkedList<Integer> actual = new DoublyLinkedList<>();
        for (int i = 0; i < 100; i++) {
            actual.pushBack(i / 50);
        }
        assertEquals(true, actual.find(0));
        assertEquals(true, actual.find(1));
        assertEquals(false, actual.find(2));
    }

}
