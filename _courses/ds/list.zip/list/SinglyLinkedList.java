package list;

public class SinglyLinkedList<E> {

    private Node<E> head;
    private Node<E> tail;
    private int size;

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        throw new UnsupportedOperationException();
    }

    public E get(int index) {
        throw new UnsupportedOperationException();
    }

    public void pushFront(E key) {
        throw new UnsupportedOperationException();
    }

    public E topFront() {
        throw new UnsupportedOperationException();
    }

    public E popFront() {
        throw new UnsupportedOperationException();
    }

    public void pushBack(E key) {
        throw new UnsupportedOperationException();
    }

    public E topBack() {
        throw new UnsupportedOperationException();
    }

    public E popBack() {
        throw new UnsupportedOperationException();
    }

    public boolean find(int key) {
        throw new UnsupportedOperationException();
    }

    public static class Node<E> {

        private E key;
        private Node<E> after;

        public Node(E key) {
            this.key = key;
        }

        public Node(E key, Node<E> after) {
            this.key = key;
            this.after = after;
        }

        public E getKey() {
            return key;
        }

        public void setKey(E key) {
            this.key = key;
        }

        public Node<E> getAfter() {
            return after;
        }

        public void setAfter(Node<E> after) {
            this.after = after;
        }

    }
}
